/**
 * Created by Json on 2015/2/13.
 */

zachModule( function () {
	var zachUtil = imports( "zachUtil" );
	module.exports = zachUtil.loopArray;
} );
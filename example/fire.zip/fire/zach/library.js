/**
 * Created by 白 on 2014/10/28.
 */

window.GestureEvent = 0;
devicePixelRatio = 0;
$ = 0;

browser = {};
browser.sheet = 0;

gc = {};
gc.webkitBackingStorePixelRatio = 0;
gc.mozBackingStorePixelRatio = 0;
gc.msBackingStorePixelRatio = 0;
gc.oBackingStorePixelRatio = 0;
gc.backingStorePixelRatio = 0;

event = {};
event.touches = 0;
event.changedTouches = 0;
event.zPageX = 0;
event.zPageY = 0;
event.zClientX = 0;
event.zClientY = 0;

safari = {};
safari.standalone = 0;

wp = {};
wp.msPointerEnabled = 0;

is = {};
is.Array = 0;
is.String = 0;
is.Number = 0;
is.Object = 0;
is.Function = 0;

array = {};
array.reverse = 0;
array.removeOut = 0;

ZachBrowser = {};
ZachBrowser.isJson = 0;
ZachBrowser.headers = 0;
ZachBrowser.image = 0;
ZachBrowser.pageLeft = 0;
ZachBrowser.pageTop = 0;

ZachCanvas = {};
ZachCanvas.drawTo = 0;
ZachCanvas.resize = 0;
ZachCanvas.draw = 0;
ZachCanvas.alter = 0;
ZachCanvas.onEnter = 0;
ZachCanvas.onLeave = 0;

ZachAnimate = {};
ZachAnimate.onStart = 0;
ZachAnimate.onAnimate = 0;
ZachAnimate.onEnd = 0;
ZachAnimate.delay = 0;

ZachRichText = {};
ZachRichText.styles = null;
ZachRichText.formats = null;
ZachRichText.handlers = null;

ZachPointer = {};
ZachPointer.curX = 0;
ZachPointer.curY = 0;
ZachPointer.startX = 0;
ZachPointer.startY = 0;

ZachServerPlus = {};
ZachServerPlus.onField = 0;
ZachServerPlus.onFile = 0;

ZachDOM = {};
ZachDOM.item = 0;
ZachDOM.addItem = 0;
ZachDOM.cutTo = 0;
ZachDOM.cutRight = 0;
ZachDOM.lay = 0;
ZachDOM.disable = 0;
ZachDOM.field = 0;
ZachDOM.lengthOf = 0;
ZachDOM.hasTemplate = 0;
ZachDOM.list = 0;
ZachDOM.addHandler = 0;
ZachDOM.handlers = 0;
ZachDOM.attr = 0;

ZachMerge = {};
ZachMerge.outDir = 0;
ZachMerge.spacer = 0;
ZachMerge.zach = 0;
ZachMerge.doUrl = 0;

CSS = {};
CSS.supports = 0;

Error.captureStackTrace = 0;
Error.getFileName = 0;

ast = 0;

zachRequireParser = {};
zachRequireParser.libPath = 0;
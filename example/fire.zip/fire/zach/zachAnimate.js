/**
 * Created by 白 on 2014/8/5.
 */

zachModule( function () {
	var math = imports( "zachMath.js" ),
		Bezier = math.Bezier,

		browser = imports( "zachBrowser.js" ),
		requestBrowserAnimate = browser.requestAnimate,

		util = imports( "zachUtil.js" ),

		Timing = {
			linear : Bezier( 1, 1, 1, 1, function ( t ) {
				return t;
			} ),
			ease : Bezier( 0.25, 0.1, 0.25, 1 ),
			easeOut : Bezier( 0, 0, .58, 1 ),
			easeInOut : Bezier( 0.42, 0, 0.58, 1 )
		};

	function fromTo( from, to, ratio ) {
		if ( util.is.Array( from ) ) {
			var retVal = [];
			util.loopArray( from, function ( from, i ) {
				retVal.push( fromTo( from, to[i], ratio ) );
			} );
			return retVal;
		}
		else {
			return from + ( to - from ) * ratio;
		}
	}

	// 进度器
	function Progress( arg ) {
		var duration = ( arg.duration || 1 ) * 1000, // 持续时间,传入的是秒数,转换为毫秒
			timing = arg.timing || Timing.ease, // 缓动函数
			progress = -( arg.delay || 0 ) * 1000, // 动画进度
			lastTime = new Date(); // 上帧时间

		return {
			// 计算当前比例
			ratio : function () {
				var now = new Date();
				progress += now - lastTime; // 更新进度
				lastTime = now;

				return progress < 0 ? null : timing( progress >= duration ? 1 : progress / duration );
			},
			// 判断进度是否结束
			isEnd : function () {
				return progress >= duration;
			},
			// 快进到目标比例
			progress : function ( targetRatio ) {
				progress = targetRatio * duration;
				lastTime = new Date()
			}
		};
	}

	function animate( arg, requestAnimate ) {
		var progress = Progress( arg ),
			isFirst = true,
			start = arg.start || 0, end = arg.end || 1;

		function go( ratio ) {
			if ( ratio !== null ) {
				if ( isFirst ) {
					arg.onStart && arg.onStart();
					isFirst = false;
				}

				arg.onAnimate( fromTo( start, end, ratio ) );

				if ( progress.isEnd() ) {
					arg.onEnd && arg.onEnd();
					animateEvent.remove();
				}
			}
		}

		go( 0 );
		var animateEvent = ( requestAnimate || requestBrowserAnimate )( function () {
			go( progress.ratio() );
		} );

		return {
			remove : animateEvent.remove,
			progress : progress.progress
		};
	}

	animate.Bezier = Bezier;
	animate.Timing = Timing;
	animate.Progress = Progress;
	animate.animate = animate;
	animate.fromTo = fromTo;
	module.exports = animate;
} );
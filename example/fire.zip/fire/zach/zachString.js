/**
 * Created by 白 on 2014/12/12.
 */

zachModule( function () {
	// 根据format制作字符串
	function formatString( format, content ) {
		var i = 0, ch, key = null, retVal = "";

		ch = format.charAt( i++ );
		while ( ch ) {
			if ( key === null ) {
				if ( ch === "%" ) {
					key = "";
				}
				else {
					retVal += ch;
				}
			}
			else {
				if ( ch === "%" ) {
					if ( key === "" ) {
						retVal += "%";
					}
					else {
						retVal += content[key] || "";
					}
					key = null;
				}
				else {
					key += ch;
				}
			}
			ch = format.charAt( i++ );
		}

		return retVal;
	}

	exports.formatString = formatString;
} );
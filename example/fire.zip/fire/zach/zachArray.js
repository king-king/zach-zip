/**
 * Created by 白 on 2014/12/12.
 */

zachModule( function () {
	var util = imports( "zachUtil.js" ),
		loopArray = util.loopArray,
		loop = util.loop;

	// 谓词
	function predicate( arg, item ) {
		return util.is.Function( arg ) ? arg( item ) : item === arg;
	}

	// 从数组中移除项,返回新数组
	function remove( arr, removeArg ) {
		var retVal = [];
		loopArray( arr, function ( item ) {
			!predicate( removeArg, item ) && retVal.push( item );
		} );
		return retVal;
	}

	// 从原数组中移除项
	function removeOut( arr, removeArg ) {
		var removeIndex = [], count = 0;
		loopArray( arr, function ( item, i ) {
			predicate( removeArg, item ) && removeIndex.push( i );
		} );
		util.loopArray( removeIndex, function ( index ) {
			arr.splice( index - count++, 1 );
		} );
	}

	// 映射
	function map( arg, map ) {
		var retVal = [];
		( util.is.Number( arg ) ? util.loop : loopArray  )( arg, function ( item ) {
			retVal.push( map( item ) );
		} );
		return retVal;
	}

	// 判断是否包含元素
	function contains( arr, containsArg ) {
		for ( var i = 0, len = arr.length; i !== len; ++i ) {
			if ( predicate( containsArg, arr[i] ) ) {
				return true;
			}
		}
		return false;
	}

	// 逆转数组,返回新数组
	function reverse( arr ) {
		var len = arr.length - 1,
			retVal = len === -1 ? [] : new Array( len );

		loopArray( arr, function ( item, i ) {
			retVal[len - i] = item;
		} );

		return retVal;
	}

	// 缝合多个数组
	function zip( arr ) {
		var retVal = [];
		loop( arr[0].length, function ( i ) {
			loopArray( arr, function ( list ) {
				retVal.push( list[i] );
			} );
		} );
		return retVal;
	}

	// 遍历区间
	function loopSection( arr, block ) {
		var previous = null;
		loopArray( arr, function ( value ) {
			previous && block( previous, value );
			previous = value;
		} );
		block( previous, null );
	}

	// 归约
	function reduce( arr, func ) {
		var retVal = func( arr[0], arr[1] );
		for ( var i = 2, len = arr.length; i <= len; ++i ) {
			retVal = func( retVal, arr[2] );
		}
		return retVal;
	}

	exports.remove = remove;
	exports.removeOut = removeOut;
	exports.map = map;
	exports.reverse = reverse;
	exports.zip = zip;
	exports.contains = contains;
	exports.loopSection = loopSection;
	exports.reduce = reduce;
} );
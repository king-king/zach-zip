/**
 * Created by Zuobai on 2014/11/22.
 */

zachModule( function () {
	var util = imports( "zachUtil.js" ),
		is = util.is,
		LinkedList = util.LinkedList;

	LinkedList.loopNodes = function ( begin, arg2, arg3, arg4 ) {
		var end, block, reverse, cur, retVal;
		if ( is.Function( arg2 ) ) {
			end = null;
			block = arg2;
			reverse = arg3;
		}
		else {
			end = arg2;
			block = arg3;
			reverse = arg4;
		}

		for ( cur = begin; cur !== end; cur = reverse ? cur.previous : cur.next ) {
			if ( ( retVal = block( cur.value, cur ) ) !== undefined ) {
				return retVal;
			}
		}
	};

	LinkedList.loopSection = function ( list, block ) {
		var start = list.head(), startValue = start.value;
		LinkedList.loopNodes( start.next, function ( value ) {
			block( startValue, value );
			startValue = value;
		} );
		block( startValue, null );
	};

	LinkedList.toArray = function ( list ) {
		var arr = [];
		LinkedList.loop( list, function ( value ) {
			arr.push( value );
		} );
		return arr;
	};

	LinkedList.push = function ( list, value ) {
		return list.insert( LinkedList.Node( value ), null );
	};

	LinkedList.pop = function ( list ) {
		var node = list.tail();
		list.remove( node );
		return node.value;
	};

	LinkedList.isBefore = function ( node1, node2 ) {
		for ( ; node2 && node2 !== node1; node2 = node2.next ) {
		}
		return node2 === null;
	};

	module.exports = LinkedList;
} );
/**
 * Created by 白 on 13-11-5.
 */

require( "./zachNode.js" );
var http = require( "http" ),
	url = require( "url" ),
	util = require( "./zachUtil" ),
	URL = require( "./zachURL" ),

	loopArray = util.loopArray,
	loopObj = util.loopObj;

// 做出响应
function respond( response, arg ) {
	response.writeHead( arg.code, arg.header );
	response.end( arg.data );
}

// 处理post
function receiveData( receiver, callback, encoding ) {
	var chunks = [], size = 0;
	receiver.on( "data", function ( postDataChunk ) {
		chunks.push( postDataChunk );
		size += postDataChunk.length;
	} );
	receiver.on( "end", function () {
		var buf = Buffer.concat( chunks, size );
		callback( encoding ? buf.toString( encoding ) : buf );
	} );
}

// 允许跨域
function allowCORS( response ) {
	response.setHeader( "Access-Control-Allow-Origin", "*" );
}

// 创建一个服务器,带端口号
function createServer( arg ) {
	var server = http.createServer( function ( request, response ) {
		arg.server( request, response );
	} );

	// 监听端口
	loopObj( arg.listen, function ( host, port ) {
		server.listen( port, host );
		console.log( "Create server on " + ( host === "" ? "*" : host ) + ":" + port );
	} );
}

// 发送http请求
function request( arg ) {
	var host = URL( arg.host ),
		contentLength = arg.data ? arg.data.length : undefined,
		headers = arg.headers || {},
		req = http.request( {
			method : arg.method || "GET",
			hostname : host.hostname,
			port : parseInt( host.port ),
			path : URL.concatArg( arg.path, arg.arg ),
			headers : util.extend( headers, {
				"Content-Length" : contentLength
			} )
		}, function ( response ) {
			receiveData( response, function ( data ) {
				arg.onSuccess && arg.onSuccess( data );
			}, arg.encoding );
		} );

	req.on( "error", function ( error ) {
		if ( arg.onError ) {
			arg.onError( error );
		}
		else {
			throw error;
		}
	} );

	arg.data && req.write( arg.data );
	req.end();
}

exports.request = request;
exports.respond = respond;
exports.createServer = createServer;
exports.receiveData = receiveData;
exports.allowCORS = allowCORS;
exports.respond = respond;
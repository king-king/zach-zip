/**
 * Created by 白 on 2014/8/15.
 */

require( "./zachNode.js" );
var Path = require( "path" ),
	util = require( "./zachUtil.js" ),
	compressor = require( 'yuicompressor' ),
	parseRequires = require( "./zachRequireParser" );

function GoOn( functionDone ) {
	return function ( stepDone ) {
		return function ( err, result ) {
			if ( err ) {
				functionDone && functionDone( err );
			}
			else {
				stepDone && stepDone( result );
			}
		};
	};
}

// 合并或压缩文件
function mergeItem( arg, mergeDone ) {
	var srcContentList = arg.contentList,
		goOn = GoOn( mergeDone );

	util.procedure( [
		// 处理arg.doFileList,请求实际的文件列表
		function ( callback ) {
			arg.doContentList ? arg.doContentList( srcContentList, goOn( callback ) ) : callback( srcContentList );
		},

		// 合并文件
		function ( inContentList ) {
			var result = {},
				mergeData = "", // 合并后的数据
				loader = util.Loader();

			// 合并内容
			util.loopArray( inContentList, function ( content, i ) {
				// 如果不是utf8,转换成utf8
				if ( content.encoding !== "uft8" ) {
					content.data = new Buffer( content.data, content.encoding ).toString( "utf8" );
					content.encoding = "utf8";
				}

				i !== 0 && ( mergeData += arg.spacer || "\n" );
				mergeData += arg.doContent ? arg.doContent( content ) : content.data;
			} );

			result.input = inContentList;

			// 如果有压缩选项,执行压缩
			if ( arg.compress ) {
				loader.load( function ( done ) {
					compressor.compressString( mergeData, {
						type : arg.type
					}, function ( err, data ) {
						if ( err ) {
							mergeDone( err );
						}
						else {
							// 处理yuicompressor的错误
							if ( arg.type === "css" ) {
								data = data.replace( /[^0-9](0)(\s)*\{/gi, function ( text ) {
									return text.replace( "0", "0%" );
								} );
							}

							result.compress = data;
						}

						done();
					} );
				} );
			}

			loader.start( function () {
				result.merge = mergeData;
				mergeDone( null, result );
			} );
		}
	] );
}

// 合并css
function mergeCSS( mergeInfo, callback ) {
	var outDir = mergeInfo.outDir;

	// 处理css压缩
	mergeItem( util.insert( mergeInfo, {
		doContent : function ( content ) {
			var inDir = Path.dirname( content.path );

			return content.data.replace( /url\(([^)]*)\)/g, function () {
				var url = RegExp.$1;
				if ( !/^data:/.test( url ) && !/:\/\//.test( url ) ) {
					url = Path.relative( outDir, Path.join( inDir, url.replace( /["']/, "" ) ) ).replace( /\\/g, "/" );
					url = mergeInfo.doUrl ? mergeInfo.doUrl( url ) : url;
					return "url(" + url + ")";
				}
			} );
		},
		type : "css"
	} ), callback );
}

// javaScript合并的头
var jsMergeClient = function () {
	var count = 0;
	window.zachModule = function ( module ) {
		zachModule[count++] = {};
		module();
	};

	window.main = window.plugin = function ( func ) {
		func();
	};
};

// 合并js
function mergeJS( mergeInfo, callback ) {
	util.request( function ( merge ) {
		if ( mergeInfo.zach ) {
			var lib = {},
				cwd = process.cwd();

			parseRequires.setLibPath( mergeInfo.zach );

			merge( {
				doContent : function ( content ) {
					var inPath = content.path,
						curPath = parseRequires.modulePath( null, "./" + Path.relative( cwd, inPath ) ),
						text = content.data;

					// 替换require
					text = text.replace( parseRequires.RequirePattern(), function () {
						return 'zachModule["' + lib[parseRequires.modulePath( inPath, parseRequires.getRequireResult( arguments ) ).toLowerCase()] + '"]';
					} );

					// 替换exports
					text = text.replace( parseRequires.ExportsPattern(), function () {
						return RegExp.$1 + 'zachModule["' + lib[curPath.toLowerCase()] + '"]';
					} );

					return text;
				},
				doContentList : function ( inContentList, done ) {
					parseRequires( inContentList, GoOn( done )( function ( requireContentList ) {
						util.loopArray( requireContentList, function ( content, i ) {
							lib[Path.resolve( content.path ).toLowerCase()] = i;
						} );

						done( null, [{
							path : "",
							data : "(" + jsMergeClient.toString() + ")();\n"
						}].concat( requireContentList, inContentList ) );
					} ) );
				}
			} );
		}
		else {
			merge();
		}
	}, function ( mergeArg ) {
		mergeItem( util.insert( mergeInfo, mergeArg || {}, {
			type : "js"
		} ), callback );
	} );
}

exports.mergeJS = mergeJS;
exports.mergeCSS = mergeCSS;
/**
 * Created by Zuobai on 2014/7/12.
 * zachCanvas 2d GUI系统
 */

zachModule( function () {
	// 引入
	var util = imports( "zachUtil" ),
		insert = util.insert,
		loopArray = util.loopArray,
		Event = util.Event,
		recursion = util.recursion,

		z2d = imports( "zach2D" ),
		matrix = z2d.matrix,
		combine = z2d.combine,
		transform = z2d.transform,
		inverse = z2d.inverse,

		browser = imports( "zachBrowser" ),
		requestAnimate = browser.requestAnimate,

		pointer = imports( "zachPointer" ),

		areaCount = 0;

	// 强化版gc
	function Context2D( gc ) {
		var prepare = [1, 0, 0, 1, 0, 0],
			cur = [1, 0, 0, 1, 0, 0],
			transformStack = [];

		// 设置矩阵
		function s() {
			var r = combine( prepare, cur );
			gc.setTransform( r[0], r[1], r[2], r[3], r[4], r[5] );
		}

		// 在当前基础上进行转换
		function t( m ) {
			cur = combine( cur, m );
			s();
		}

		// 几个经典转换
		function ClassicTransform( genFunc ) {
			return function () {
				t( genFunc.apply( null, arguments ) );
			}
		}

		util.defineGetter( gc, {
			transformation : function () {
				return combine( gc.getTransform(), gc.layer.transformation || matrix.eye() );
			}
		} );

		return insert( gc, {
			// 该方法用于设置一个预矩阵,解决dpr变换
			setPrepareTransform : function ( m ) {
				prepare = m;
				s();
			},
			transform : function () {
				t( arguments );
			},
			getTransform : function () {
				return [cur[0], cur[1], cur[2], cur[3], cur[4], cur[5]];
			},
			save : function () {
				CanvasRenderingContext2D.prototype.save.call( gc );
				transformStack.push( cur );
			},
			restore : function () {
				CanvasRenderingContext2D.prototype.restore.call( gc );
				cur = transformStack.pop();
				s();
			},
			translate : ClassicTransform( matrix.translate ),
			rotate : ClassicTransform( matrix.rotate ),
			scale : ClassicTransform( matrix.scale )
		} );
	}

	function Layer() {
		var layer = document.createElement( "canvas" ),
			gc = Context2D( layer.getContext( "2d" ) ),
			dpr = 1;

		layer.style.setProperty( "display", "block", "" );

		// dpr属性
		util.defineAutoProperty( layer, "dpr", {
			value : ( window.devicePixelRatio || 1 ) / ( gc.webkitBackingStorePixelRatio || gc.mozBackingStorePixelRatio ||
			gc.msBackingStorePixelRatio || gc.oBackingStorePixelRatio || gc.backingStorePixelRatio || 1 ),
			set : function ( val ) {
				gc.dpr = dpr = val;
				gc.setPrepareTransform( matrix.scale( val, val ) );
			}
		} );

		return insert( layer, {
			isDirty : true,
			clear : true,
			// 在层上进行绘制
			redraw : function ( drawFunc ) {
				layer.clear && gc.clearRect( 0, 0, layer.width, layer.height );
				gc.layer = layer;
				gc.save();
				drawFunc( gc );
				gc.restore();
			},
			// 调整大小
			resize : function ( width, height ) {
				layer.width = width * layer.dpr;
				layer.height = height * layer.dpr;
				layer.style.setProperty( "width", ( layer.logicalWidth = width ) + "px", "" );
				layer.style.setProperty( "height", ( layer.logicalHeight = height ) + "px", "" );
				layer.dpr = dpr;
			},
			// 将该层绘制到父层上,记录该层到复层的变换以及parent关系
			draw : function ( parentGC ) {
				layer.parentLayer = parentGC.layer;
				layer.transformation = combine( parentGC.getTransform(), parentGC.layer.transformation );
				parentGC.drawImage( layer, 0, 0, layer.width, layer.height );
			},
			// 置脏位
			dirty : function () {
				layer.isDirty = true;
				layer.parentLayer && layer.parentLayer.dirty();
			}
		} );
	}

	// Area
	function Area() {
		var drawEvent = Event(),
			enterEvent = Event(),
			leaveEvent = Event(),

			area = {
				id : areaCount++,
				areaFromPoint : null,
				dirty : function () {
					area.parentLayer && area.parentLayer.dirty();
				},
				draw : function ( gc ) {
					area.transformation = gc.transformation;
					area.parentLayer = gc.layer;
					drawEvent.trig( gc );
				},
				onDraw : drawEvent.regist,
				onEnter : enterEvent.regist,
				enter : enterEvent.trig,
				onLeave : leaveEvent.regist,
				leave : leaveEvent.trig
			};

		return area;
	}

	// 将一个点由page坐标系,转换到area的坐标系
	function coordinatePageToArea( area, p ) {
		return transform( inverse( area.transformation ), p );
	}

	// 将一个点由area坐标系,转换到page坐标系
	function coordinateAreaToPage( area, p ) {
		return transform( area.transformation, p );
	}

	function Canvas() {
		var canvas = Layer(),
			requestAnimateEvent = Event(),
			hoverList = [],
			drawEvent = Event(),
			isHover = false,
			cursorX = 0, cursorY = 0; // 动画事件

		// 通过点获取悬停列表
		function getHoverListByPoint( pageX, pageY ) {
			var hoverList = [];

			recursion( function getArea( area ) {
				if ( area && area.transformation ) {
					hoverList.push( area );
					loopArray( area.areaFromPoint ? [].concat( area.areaFromPoint.apply( null, coordinatePageToArea( area, [pageX, pageY, 1] ) ) ) : [], getArea );
				}
			}, canvas.areaFromPoint ? canvas.areaFromPoint( pageX, pageY ) : null );
			return hoverList;
		}

		// 更新hoverList
		function updateHoverList( newList ) {
			loopArray( hoverList, function ( area ) {
				area.isHover = false;
			} );

			loopArray( newList, function ( area, i ) {
				var enter = area.hoverIndex === undefined;
				area.hoverIndex = i;
				area.isHover = true;
				enter && area.enter();
			} );

			loopArray( hoverList, function ( area ) {
				if ( !area.isHover && area.hoverIndex !== undefined ) {
					area.leave();
					delete area.hoverIndex;
				}
			} );

			hoverList = newList;
		}

		// 通过点事件更新悬停列表
		var updateHoverListByPointEvent = function ( event, pageX, pageY ) {
			isHover = true;
			updateHoverList( getHoverListByPoint( cursorX = pageX, cursorY = pageY ) );
		};

		function leaveCanvas() {
			isHover = false;
			updateHoverList( [] );
		}

		// 计算hover
		if ( ua.canTouch ) {
			pointer.onPointerDown( canvas, updateHoverListByPointEvent, true );
			pointer.onPointerMove( canvas, updateHoverListByPointEvent, true );
			pointer.onPointerUp( document, leaveCanvas );
		}
		else {
			browser.bindEvent( canvas, ua.msPointer ? "MSPointerOver" : "mouseover", updateHoverListByPointEvent, true );
			pointer.onPointerMove( canvas, updateHoverListByPointEvent, true );
			browser.bindEvent( canvas, ua.msPointer ? "MSPointerOut" : "mouseout", leaveCanvas, true );
		}

		// 重绘激励
		requestAnimate( function () {
			requestAnimateEvent.trig();

			// 回调draw事件
			if ( canvas.isDirty ) {
				canvas.isDirty = false;
				canvas.redraw( drawEvent.trig );
				isHover && updateHoverListByPointEvent( null, cursorX, cursorY );
			}
		} );

		// 如果改变了位置,重新计算canvas在页面上的位置
		function alter() {
			canvas.transformation = matrix.translate( canvas.pageLeft, canvas.pageTop );
		}

		// 插入时计算位置
		browser.onInsert( canvas, alter );

		return insert( canvas, {
			requestAnimate : requestAnimateEvent.regist,
			onDraw : drawEvent.regist,
			alter : alter
		} );
	}

	Canvas.Context2D = Context2D;
	Canvas.Layer = Layer;
	Canvas.Area = Area;
	Canvas.coordinatePageToArea = coordinatePageToArea;
	Canvas.coordinateAreaToPage = coordinateAreaToPage;

	module.exports = Canvas;
} );
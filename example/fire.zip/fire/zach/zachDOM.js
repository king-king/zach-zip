/**
 * Created by 白 on 2014/10/29.
 * 封装一些DOM经典复用
 */

zachModule( function () {
	var util = imports( "zachUtil.js" ),
		is = util.is,
		loopArray = util.loopArray,
		loopObj = util.loopObj,
		tupleString = util.tupleString,
		LinkedList = util.LinkedList,

		browser = imports( "zachBrowser.js" ),
		bindEvent = browser.bindEvent;

	// region css
	// 测试某个样式是否有效
	var testCSS = function () {
		if ( window.CSS && CSS.supports ) {
			return function ( styleName, styleValue ) {
				return CSS.supports( styleName, styleValue );
			};
		}
		else {
			var testElement = document.createElement( "div" );

			return function ( styleName, styleValue ) {
				testElement.removeAttribute( "style" );
				testElement.style.setProperty( styleName, styleValue, "" );
				return is.String( testElement.getAttribute( "style" ) );
			};
		}
	}();

	// 测试某个样式的样式名(找前缀)
	var testStyleName = function () {
		var prefix = "";

		return function ( styleName, styleValue ) {
			function test( prefix ) {
				return testCSS( prefix + styleName, styleValue );
			}

			if ( test( "" ) ) {
				return styleName;
			}
			else {
				if ( prefix ) {
					return test( prefix ) ? prefix + styleName : styleName;
				}
				else {
					return util.loopArray( ["-webkit-", "-ms-", "-moz-", "-o-"], function ( targetPrefix ) {
						if ( test( targetPrefix ) ) {
							prefix = targetPrefix;
							return true;
						}
					} ) ? prefix + styleName : styleName;
				}
			}
		};
	}();

	// 设置样式
	function css( el, arg1, arg2 ) {
		function setStyle( styleName, styleValue ) {
			el.style.setProperty( testStyleName( styleName, styleValue ), styleValue, "" );
		}

		is.String( arg1 ) ? setStyle( arg1, arg2 ) : loopObj( arg1, setStyle );
		return el;
	}

	// 生成CSS样式字符串
	function cssRuleString( cssStyles ) {
		var ruleText = "";
		loopObj( cssStyles, function ( styleName, styleValue ) {
			ruleText += testStyleName( styleName, styleValue ) + ":" + styleValue + ";";
		} );
		return ruleText;
	}

	// 移除CSS值,可以移除一条,或者移除一组
	function removeCSS( el, arg ) {
		function removeStyle( styleName ) {
			loopArray( ["", "-webkit-", "-ms-", "-moz-", "-o-"], function ( prefix ) {
				el.style.removeProperty( prefix + styleName );
			} );
		}

		is.String( arg ) ? removeStyle( arg ) : is.Object( arg ) ? loopObj( arg, removeStyle ) : loopArray( arg, removeStyle );
		return el;
	}

	// 添加CSS规则
	var insertCSSRule = function () {
		var userSheet = LinkedList(), systemSheet = LinkedList();
		return function ( ruleText, isSystem ) {
			var styleSheet = isSystem ? systemSheet : userSheet; // 选择样式链表

			// 如果节点尚未创建,创建节点,系统样式表在所有样式表的最前,用户样式表在所有样式表的最后
			if ( styleSheet.el === undefined ) {
				styleSheet.el = document.head.insertBefore( document.createElement( "style" ), isSystem ? document.head.firstChild : null );
			}

			// 创建新规则,位置上最后规则+1
			var lastRule = styleSheet.tail(),
				newRule = styleSheet.insert( LinkedList.Node( lastRule === null ? 0 : lastRule.value + 1 ), null );

			styleSheet.el.sheet.insertRule( ruleText, newRule.value );

			return {
				remove : function () {
					// 后面所有元素的位置-1
					var pos = newRule.value;
					for ( var curNode = newRule.next; curNode !== null; curNode = curNode.next ) {
						curNode.value = pos++;
					}

					// 移除节点并删除规则
					styleSheet.remove( newRule );
					styleSheet.el.sheet.deleteRule( pos );
				}
			};
		}
	}();

	function insertCSSRules( arg1, arg2, arg3 ) {
		function insertRules( selector, styles, isSystem ) {
			var cssText = is.String( styles ) ? styles : cssRuleString( styles );
			insertCSSRule( selector + " {" + cssText + "}", isSystem );
		}

		if ( is.String( arg1 ) ) {
			insertRules( arg1, arg2, arg3 );
		}
		else {
			loopObj( arg1, function ( selector, styles ) {
				insertRules( selector, styles, arg2 );
			} );
		}
	}

	function n( n ) {
		return Math.abs( n ) < 0.01 ? 0 : n;
	}

	css.size = function ( el, width, height ) {
		css( el, {
			width : width + "px",
			height : height + "px"
		} );
	};

	css.transform = function () {
		var style = [];
		loopArray( arguments, function ( transform, i ) {
			i !== 0 && style.push( transform );
		} );
		css( arguments[0], "transform", style.join( " " ) );
	};

	css.matrix = function ( m ) {
		return tupleString( "matrix", [n( m[0] ), n( m[1] ), n( m[2] ), n( m[3] ), n( m[4] ), n( m[5] )] );
	};

	css.translate = function ( x, y, z ) {
		return tupleString( "translate3d", [n( x ) + "px", n( y ) + "px", n( z ) + "px"] );
	};

	function Rotate( name ) {
		return function ( val, unit ) {
			return tupleString( name, [n( val ) + ( unit || "rad" )] );
		};
	}

	css.rotateX = Rotate( "rotateX" );
	css.rotateY = Rotate( "rotateY" );
	css.rotateZ = Rotate( "rotateZ" );

	css.scale = function () {
		return "scale(" + Array.prototype.join.call( arguments, "," ) + ")";
	};

	css.px = function ( value ) {
		return value === 0 ? 0 : n( value ) + "px";
	};

	css.s = function ( value ) {
		return value === 0 ? 0 : n( value ) + "s";
	};

	css.url = function ( url ) {
		return "url(" + url + ")";
	};

	// transitionEnd事件
	function onTransitionEnd( el, task ) {
		var handle = bindEvent( el, "webkitTransitionEnd", function () {
			handle.remove();
			task();
		} );
	}

	// 过渡
	function transition( el, transition, style, styleValue, onEnd ) {
		onEnd = is.String( style ) ? onEnd : styleValue;

		if ( ua.android && ua.androidVersion < 3 ) {
			css( el, style, styleValue );
			onEnd && onEnd();
		}
		else {
			css( el, "transition", transition );
			el.transition && el.transition.remove();

			function end() {
				if ( el.transition ) {
					transitionEnd.remove();
					removeEvent.remove();
					removeCSS( el, "transition" );
					onEnd && onEnd();
					el.transition = null;
				}
			}

			var removeEvent = bindEvent( el, "DOMNodeRemovedFromDocument", end ),
				transitionEnd = el.transition = bindEvent( el, "webkitTransitionEnd", end );

			setTimeout( function () {
				css( el, style, styleValue );
			}, 20 );
		}
	}

	// endregion

	// region DOM
	// 从文档中移除元素
	function removeNode( node ) {
		node && node.parentNode && node.parentNode.removeChild( node );
	}

	// 创建一个元素的快捷方式
	function element( arg1, arg2, arg3 ) {
		var el, elementArg = {}, parent = arg3;

		// 如果是<div></div>这种形式,直接制作成元素
		if ( arg1.charAt( 0 ) === "<" ) {
			el = document.createElement( "div" );
			el.innerHTML = arg1;
			el = el.firstElementChild;
		}
		// 否则是div.class1.class2#id这种形式
		else {
			var classIdReg = /([.#][^.#]*)/g, classId;
			el = document.createElement( arg1.split( /[#.]/ )[0] );
			while ( classId = classIdReg.exec( arg1 ) ) {
				classId = classId[0];
				classId.charAt( 0 ) === "#" ? el.id = classId.substring( 1 ) : el.classList.add( classId.substring( 1 ) );
			}
		}

		// 参数2是字符串,作为innerHTML
		if ( is.String( arg2 ) ) {
			el.innerHTML = arg2;
		}
		// 是对象的话,每个字段处理
		else if ( is.Object( arg2 ) ) {
			elementArg = arg2;
		}
		// 如果是数组,视为子元素
		else if ( is.Array( arg2 ) ) {
			elementArg.children = arg2;
		}
		// 否则视为父元素
		else {
			parent = arg2;
		}

		elementArg && loopObj( elementArg, function ( key, value ) {
			if ( value !== undefined ) {
				switch ( key ) {
					case "classList":
						if ( is.String( value ) ) {
							el.classList.add( value );
						}
						else if ( is.Array( value ) ) {
							loopArray( value, function ( className ) {
								el.classList.add( className );
							} );
						}
						break;
					case "css":
						css( el, value );
						break;
					case "children":
						if ( is.Array( value ) ) {
							loopArray( value, function ( node ) {
								el.appendChild( node );
							} );
						}
						else {
							el.appendChild( value );
						}
						break;
					default:
						if ( key.substring( 0, 5 ) === "data-" ) {
							el.setAttribute( key, value );
						}
						else {
							el[key] = value;
						}
						break;
				}
			}
		} );

		parent && parent.appendChild( el );
		return el;
	}

	// 根据flag添加或删除class
	function switchClass( el, flag, className ) {
		flag ? el.classList.add( className ) : el.classList.remove( className );
	}

	// 切换状态,将class从fromState切换到toState
	function toggleState( el, fromState, toState ) {
		el.classList.remove( fromState );
		el.classList.add( toState );
	}

	// 沿着一个元素向上冒泡,直到root/document,回调每个节点
	function bubble( el, func, root ) {
		var val;
		while ( el !== null && el !== document && el !== root ) {
			if ( val = func( el ) ) {
				return val;
			}
			el = el.parentNode;
		}
	}

	// 当一个事件冒泡到document时,回调冒泡中的每个节点
	function onBubble( eventName, response ) {
		document.addEventListener( eventName, function ( event ) {
			bubble( event.target, function ( node ) {
				response( node );
			}, document.documentElement );
		}, false );
	}

	// 寻找祖先节点
	function findAncestor( el, func ) {
		return bubble( el, function ( el ) {
			if ( func( el ) ) {
				return el;
			}
		} );
	}

	// 焦点时设置focus类
	browser.onLoad( function () {
		onBubble( "focusin", function ( node ) {
			node.classList.add( "focus" );
		} );
		onBubble( "focusout", function ( node ) {
			node.classList.remove( "focus" );
		} );
	} );
	// endregion

	// region 导出
	// css
	exports.testCSS = testCSS;
	exports.css = css;
	exports.removeCSS = removeCSS;
	exports.cssRuleString = cssRuleString;
	exports.insertCSSRule = insertCSSRule;
	exports.insertCSSRules = insertCSSRules;
	exports.onTransitionEnd = onTransitionEnd;
	exports.transition = transition;

	// DOM
	exports.element = element;
	exports.removeNode = removeNode;
	exports.toggleState = toggleState;
	exports.switchClass = switchClass;
	exports.bubble = bubble;
	exports.onBubble = onBubble;
	exports.findAncestor = findAncestor;

	// 导出
	exports.toAbsURL = browser.toAbsURL;
	exports.bindEvent = bindEvent;
	exports.Bind = browser.Bind;
	exports.onInsert = browser.onInsert;
	exports.requestAnimate = browser.requestAnimate;
	exports.ajax = browser.ajax;
	exports.onLoad = browser.onLoad;
	// endregion
} );
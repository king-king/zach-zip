/**
 * Created by 白 on 2015/1/21.
 */

zachModule( function () {
	var util = imports( "zachUtil.js" ),
		loopObj = util.loopObj,
		loopArray = util.loopArray,
		extend = util.extend,
		defineGetter = util.defineGetter,
		exclude = util.exclude;

	// 将对象转化问URI字符串
	function encodeObject( obj ) {
		var retVal = "", i = 0;
		loopObj( obj || {}, function ( key, value ) {
			if ( value !== undefined ) {
				i++ && ( retVal += "&" );
				retVal += encodeURIComponent( key );
				retVal += '=';
				retVal += encodeURIComponent( value );
			}
		} );
		return retVal;
	}

	// 解析配对连接字符串,如name=tom&class=2&grade=3
	function parsePairString( str, split1, split2, doPair ) {
		loopArray( str.split( split1 ), function ( searchPair ) {
			var keyValue = searchPair.split( split2 );
			doPair( keyValue[0], keyValue[1] );
		} );
	}

	// 为字符串提供url解析功能
	var regUrl = /(?:((?:[^:/]*):)\/\/)?([^:/?#]*)(?::([0-9]*))?(\/[^?#]*)?(\?[^#]*)?(#.*)?/;

	function ZachURL( str ) {
		this.href = str;
		if ( regUrl.test( str ) ) {
			this.protocol = RegExp.$1;
			this.hostname = RegExp.$2;
			this.port = RegExp.$3;
			this.pathname = RegExp.$4;
			this.search = RegExp.$5;
			this.hash = RegExp.$6;
		}
	}

	//noinspection JSUnusedGlobalSymbols
	ZachURL.prototype.inspect = ZachURL.prototype.valueOf = ZachURL.prototype.toString = ZachURL.prototype.toJSON = function () {
		return this.href;
	};

	loopObj( {
		host : function () {
			return this.hostname + ( this.port ? ":" + this.port : "" );
		},
		origin : function () {
			return this.protocol ? this.protocol + "//" + this.host : this.host;
		},
		arg : function () {
			var arg = {};
			parsePairString( this.search.substring( 1 ), "&", "=", function ( key, value ) {
				key !== "" && ( arg[key] = decodeURIComponent( value ) );
			} );
			return arg;
		}
	}, function ( name, func ) {
		defineGetter( ZachURL.prototype, name, func );
	} );

	function URL( str ) {
		return new ZachURL( str );
	}

	function concatArg( url, arg ) {
		url = URL( url );
		var newSearch = encodeObject( extend( url.arg, arg ) );
		return url.origin + url.pathname + ( newSearch ? "?" : "" ) + newSearch + url.hash;
	}

	function removeArg( url, argNameList ) {
		url = URL( url );
		var newSearch = encodeObject( exclude( url.arg, argNameList ) );
		return url.origin + url.pathname + ( newSearch ? "?" : "" ) + newSearch + url.hash;
	}

	module.exports = URL;
	URL.encodeObject = encodeObject;
	URL.concatArg = concatArg;
	URL.removeArg = removeArg;
} );
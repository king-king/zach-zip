/**
 * Created by Zuobai on 13-12-8.
 */

zachModule( function () {
	// region 遍历
	// 遍历次数
	function loop( t, block ) {
		for ( var i = 0; i !== t; ++i ) {
			block( i );
		}
	}

	// 遍历数组
	function loopArray( list, block ) {
		var retVal;
		for ( var i = 0, len = list.length; i !== len; ++i ) {
			if ( ( retVal = block( list[i], i ) ) !== undefined ) {
				return retVal;
			}
		}
	}

	// 遍历对象
	function loopObj( obj, block ) {
		var retVal;
		for ( var key in obj ) {
			if ( ( retVal = block( key, obj[key] ) !== undefined ) ) {
				return retVal;
			}
		}
	}

	// 遍历字符串
	function loopString( string, func, isChar ) {
		var i, len;
		for ( i = 0, len = string.length; i !== len; ++i ) {
			func( isChar ? string.charAt( i ) : string.charCodeAt( i ), i );
		}
	}

	// endregion

	// region 对象
	function defaultValue( val, defaultValue ) {
		return val === undefined ? defaultValue : val;
	}

	function merge( outObj, inObjList ) {
		loopArray( inObjList, function ( obj ) {
			loopObj( obj, function ( key, value ) {
				value !== undefined && ( outObj[key] = value );
			} );
		} );
		return outObj;
	}

	// 将若干个对象合并到第一个对象中,并返回第一个对象
	function insert( obj ) {
		return merge( obj, Array.prototype.slice.call( arguments, 1 ) );
	}

	// 将若干个对象合并,返回合并后的新对象
	function extend() {
		var retVal = {};
		return merge( retVal, arguments );
	}

	// 从obj中取出defaultObj中的字段,如果obj中没有这个字段,使用defaultObj的值
	function extract( obj, defaultObj ) {
		var retVal = {};
		loopObj( defaultObj, function ( key, val ) {
			retVal[key] = defaultValue( obj[key], val );
		} );
		return retVal;
	}

	// 从obj中移除字段,返回移除后的新对象
	function exclude( obj, fieldList ) {
		var fieldSet = Set( fieldList ),
			retVal = {};

		loopObj( obj, function ( key, value ) {
			!fieldSet.contains( key ) && ( retVal[key] = value );
		} );

		return retVal;
	}

	// 返回一个字典的key数组
	function keys( obj ) {
		var retVal = [];
		loopObj( obj, function ( key ) {
			retVal.push( key );
		} );
		return retVal;
	}

	// 定义getter
	function defineGetter( obj, arg1, arg2 ) {
		request( function ( def ) {
			is.String( arg1 ) ? def( arg1, arg2 ) : loopObj( arg1, def );
		}, function ( name, func ) {
			Object.defineProperty( obj, name, {
				get : func
			} );
		} );
	}

	// 定义自动对象
	function defineAutoProperty( obj, arg1, arg2 ) {
		request( function ( def ) {
			is.String( arg1 ) ? def( arg1, arg2 ) : loopObj( arg1, def );
		}, function ( name, arg ) {
			arg = arg || {};
			var val = arg.value, write = arg.set;
			val !== undefined && write( val );

			Object.defineProperty( obj, name, {
				get : function () {
					return val;
				},
				set : function ( tVal ) {
					val = write ? defaultValue( write( tVal ), tVal ) : tVal;
				}
			} );
		} );
	}

	// endregion

	// region 技巧
	// 对象类型判断
	var is = (function () {
		var is = {};
		loopArray( ["Array", "Boolean", "Date", "Function", "Number", "Object", "RegExp", "String", "Window", "HTMLDocument"], function ( typeName ) {
			is[typeName] = function ( obj ) {
				return Object.prototype.toString.call( obj ) == "[object " + typeName + "]";
			};
		} );
		return is;
	})();

	// 根据函数字符串调用函数
	function callFunction( funcStr ) {
		return new Function( "return " + funcStr )().apply( null, Array.prototype.slice.call( arguments, 1 ) );
	}

	// endregion

	// region 字符串
	// 将一个元组转化为字符串
	function tupleString( tupleName, list ) {
		return tupleName + "(" + list.join( "," ) + ")";
	}

	// 返回一个元祖字符串制作函数,如TupleString( "rgba" )( 2, 3, 4, 0.4 )会返回rgba(2,3,4,0.4);
	function TupleString( tupleName ) {
		return function () {
			return tupleName + "(" + Array.prototype.join.call( arguments, "," ) + ")";
		};
	}

	// endregion

	// region 链表
	// 双向链表
	function LinkedList() {
		var head = null, tail = null;

		return {
			head : function () {
				return head;
			},
			tail : function () {
				return tail;
			},
			insert : function ( tarNode, refNode ) {
				var previous = refNode ? refNode.previous : tail;
				tarNode.next = refNode;
				tarNode.previous = previous;
				previous ? previous.next = tarNode : head = tarNode;
				refNode ? refNode.previous = tarNode : tail = tarNode;
				tarNode.inserted = true;
				return tarNode;
			},
			remove : function ( node ) {
				if ( node.inserted === true ) {
					node.previous ? node.previous.next = node.next : head = node.next;
					node.next ? node.next.previous = node.previous : tail = node.previous;
					node.inserted = false;
				}
			}
		};
	}

	LinkedList.Node = function ( value ) {
		return {
			previous : null,
			next : null,
			value : value
		};
	};

	LinkedList.loop = function ( list, func ) {
		var retVal;
		for ( var cur = list.head(); cur !== null; cur = cur.next ) {
			if ( ( retVal = func( cur.value, cur ) ) !== undefined ) {
				return retVal;
			}
		}
	};
	// endregion

	// region 数组
	try {
		// 提供数组的top
		Object.defineProperty( Array.prototype, "top", {
			get : function () {
				return this[this.length - 1];
			},
			set : function ( val ) {
				this[this.length - 1] = val;
			},
			enumerable : false
		} );
	}
	catch ( e ) {
	}
	// endregion

	// region 数据结构
	// 集合,根据一个数组构建一个集合,用来判断一个key是否属于集合
	function Set( arr ) {
		var dict = {};
		loopArray( arr, function ( item ) {
			dict[item] = true;
		} );

		return {
			contains : function ( key ) {
				return dict[key] === true;
			}
		};
	}

	// endregion

	// region 异步编程
	// 事件
	function Event() {
		var events = LinkedList();

		return {
			trig : function () {
				for ( var cur = events.head(); cur !== null; cur = cur.next ) {
					cur.value.apply( null, arguments );
				}
			},
			regist : function ( value ) {
				var node = events.insert( LinkedList.Node( value ), null );
				return {
					remove : function () {
						events.remove( node );
					}
				};
			}
		};
	}

	// 递归
	function recursion( func ) {
		func.apply( null, Array.prototype.slice.call( arguments, 1 ) );
	}

	// 装载器
	function Loader( inOrder ) {
		var taskList = [];

		return {
			load : function ( task ) {
				taskList.push( task );
			},
			start : function ( onLoad ) {
				if ( taskList.length === 0 ) {
					onLoad();
				}
				else if ( inOrder ) {
					recursion( function load( index ) {
						var task = taskList[index];
						task ? task( function () {
							load( index + 1 )
						} ) : onLoad();
					}, 0 );
				}
				else {
					var count = taskList.length;
					loopArray( taskList, function ( task ) {
						task( function () {
							--count === 0 && onLoad();
						} );
					} );
				}
			}
		}
	}

	// 资源,需要加载使用,但全局只会加载一次
	function Resource( load ) {
		var resource, onLoadList;

		return {
			load : function ( onLoad ) {
				// 如果还有装载函数表示装载没有完成
				if ( load ) {
					// 如果没有onLoad数组,创建装载列表,并开始装载
					if ( !onLoadList ) {
						onLoadList = [];
						load( function ( targetResource ) {
							resource = targetResource;
							loopArray( onLoadList, function ( onLoad ) {
								onLoad( resource );
							} );
							onLoadList = null;
							load = null;
						} );
					}

					onLoadList.push( onLoad );
				}
				// 否则直接回调
				else {
					onLoad( resource );
				}
			}
		};
	}

	function procedure( step ) {
		var len = step.length;

		recursion( function call( i, arg ) {
			var func = step[i];
			if ( func ) {
				func.apply( null, i === len - 1 ? arg : [function () {
					call( i + 1, Array.prototype.slice.call( arguments, 0 ) );
				}].concat( arg ) );
			}
		}, 0, [] );
	}

	function request( request, callback ) {
		return request( callback );
	}

	// 异步遍历数组
	function loopArrayAsync( array, onItem, onDone, inOrder ) {
		var loader = Loader( inOrder );
		loopArray( array, function ( item, i ) {
			loader.load( function ( done ) {
				onItem( done, item, i );
			} );
		} );
		loader.start( onDone );
	}

	// endregion

	// region 导出
	// 技巧
	exports.is = is;
	exports.callFunction = callFunction;

	// 遍历
	exports.loop = loop;
	exports.loopArray = loopArray;
	exports.loopObj = loopObj;
	exports.loopString = loopString;

	// 对象
	exports.defaultValue = defaultValue;
	exports.insert = insert;
	exports.extend = extend;
	exports.extract = extract;
	exports.exclude = exclude;
	exports.keys = keys;
	exports.defineGetter = defineGetter;
	exports.defineAutoProperty = defineAutoProperty;

	// 字符串
	exports.tupleString = tupleString;
	exports.TupleString = TupleString;

	// 数据结构
	exports.Set = Set;
	exports.LinkedList = LinkedList;

	// 异步编程
	exports.Event = Event;
	exports.Loader = Loader;
	exports.Resource = Resource;
	exports.procedure = procedure;
	exports.recursion = recursion;
	exports.request = request;
	exports.loopArrayAsync = loopArrayAsync;
	// endregion
} );
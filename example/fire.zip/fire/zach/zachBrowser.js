/**
 * Created by Zuobai on 14-1-10.
 * 经典浏览器封装
 */

zachModule( function () {
	// region 引入
	var util = imports( "zachUtil.js" ),
		URL = imports( "zachURL" ),
		insert = util.insert,
		loopArray = util.loopArray,
		loopObj = util.loopObj,
		LinkedList = util.LinkedList,
		defineGetter = util.defineGetter,
		Event = util.Event;
	// endregion

	// region 浏览器检测
	(function ( ua, appVersion, platform ) {
		insert( window.ua = window.ua || {}, {
			// win系列
			win32 : platform === "Win32",
			ie : !!window.ActiveXObject || "ActiveXObject" in window,
			ieVersion : Math.floor( (/MSIE ([^;]+)/.exec( ua ) || [0, "0"])[1] ),

			// ios系列
			ios : (/iphone|ipad/gi).test( appVersion ),
			iphone : (/iphone/gi).test( appVersion ),
			ipad : (/ipad/gi).test( appVersion ),
			iosVersion : parseFloat( ('' + (/CPU.*OS ([0-9_]{1,5})|(CPU like).*AppleWebKit.*Mobile/i.exec( ua ) || [0, ''])[1])
				.replace( 'undefined', '3_2' ).replace( '_', '.' ).replace( '_', '' ) ) || false,
			safari : /Version\//gi.test( appVersion ) && /Safari/gi.test( appVersion ),
			uiWebView : /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test( ua ),

			// 安卓系列
			android : (/android/gi).test( appVersion ),
			androidVersion : parseFloat( "" + (/android ([0-9\.]*)/i.exec( ua ) || [0, ''])[1] ),

			// chrome
			chrome : /Chrome/gi.test( ua ),
			chromeVersion : parseInt( ( /Chrome\/([0-9]*)/gi.exec( ua ) || [0, 0] )[1], 10 ),

			// 内核
			webkit : /AppleWebKit/.test( appVersion ),

			// 其他浏览器
			uc : appVersion.indexOf( "UCBrowser" ) !== -1,
			Browser : / Browser/gi.test( appVersion ),
			MiuiBrowser : /MiuiBrowser/gi.test( appVersion ),

			// 微信
			MicroMessenger : ua.toLowerCase().match( /MicroMessenger/i ) == "micromessenger",

			// 触摸
			canTouch : "ontouchstart" in document,
			msPointer : window.navigator.msPointerEnabled
		} );
	})( navigator.userAgent, navigator.appVersion, navigator.platform );
	// endregion

	// region 路径
	// 将相对地址转换为绝对地址
	function toAbsURL( url ) {
		var a = document.createElement( 'a' );
		a.href = url;
		return a.href;
	}

	// endregion

	// region 浏览器扩展
	// 为元素添加pageLeft和pageTop属性,元素相对于文档的偏移
	loopArray( ["Left", "Top"], function ( direction ) {
		defineGetter( HTMLElement.prototype, "page" + direction, function () {
			var retVal = 0, cur, body = document.body;

			for ( cur = this; cur !== body; cur = cur.offsetParent || cur.parentElement ) {
				retVal += cur["offset" + direction] - ( cur === this ? 0 : cur["scroll" + direction] );
			}

			return retVal;
		} );
	} );

	// 为UIEvent添加zPageX,zPageY,zClientX,zClientY属性,统一触摸和鼠标
	loopArray( ["pageX", "pageY", "clientX", "clientY"], function ( coordinateName ) {
		Object.defineProperty( UIEvent.prototype, "z" + coordinateName.replace( /^./, function ( ch ) {
			return ch.toUpperCase();
		} ), {
			get : function () {
				return "touches" in this && this.touches[0] !== undefined ? this.touches[0][coordinateName] : this[coordinateName];
			}
		} );
	} );
	// endregion

	// region 动画
	// 请求连续动画
	var requestAnimate = function () {
		var timeout = null, tasks = LinkedList();

		return function ( task ) {
			var node = null;

			function start() {
				// 如果任务没有添加进链表,添加到链表中
				if ( node === null ) {
					node = tasks.insert( LinkedList.Node( task ), null );

					// 如果当前没有计时,开始计时
					if ( timeout === null ) {
						timeout = setTimeout( function frame() {
							var cur;
							if ( tasks.tail() !== null ) {
								timeout = setTimeout( frame, 1000 / 60 );
								for ( cur = tasks.head(); cur !== null; cur = cur.next ) {
									cur.value();
								}
							}
							else {
								timeout = null;
							}
						}, 1000 / 60 );
					}
				}
			}

			start();

			return {
				start : start,
				remove : function () {
					node && tasks.remove( node );
					node = null;
				}
			};
		};
	}();

	// endregion

	// region 事件
	// 绑定事件
	function bindEvent( el, eventType, response, isCapture ) {
		var remove;

		if ( el.addEventListener ) {
			el.addEventListener( eventType, response, isCapture || false );
			remove = function () {
				el.removeEventListener( eventType, response, isCapture || false );
			};
		}
		else {
			el.attachEvent( "on" + eventType, response );
			remove = function () {
				el.detachEvent( "on" + eventType, response );
			};
		}

		return {
			remove : remove
		};
	}

	// 制作一个事件绑定器
	function Bind( eventType ) {
		return function ( el, response, isCapture ) {
			return bindEvent( el, eventType, response, isCapture );
		};
	}

	// 当元素插入到文档时回调
	function onInsert( el, response ) {
		if ( document.documentElement.contains( el ) ) {
			response && response();
		}
		else {
			if ( ua.ie && window.MutationObserver ) {
				var observer = new MutationObserver( function ( mutations ) {
					loopArray( mutations, function ( mutation ) {
						return loopArray( mutation.addedNodes || [], function ( node ) {
							if ( node === el ) {
								observer.disconnect();
								response && response( el );
								return true;
							}
						} );
					} );
				} );

				//noinspection JSCheckFunctionSignatures
				observer.observe( document.documentElement, {
					childList : true,
					subtree : true
				} );
			}
			else {
				var insertEvent = bindEvent( el, "DOMNodeInsertedIntoDocument", function () {
					response && response( el );
					insertEvent.remove();
				} );
			}
		}
	}

	// endregion

	// region ajax
	function ajax( arg ) {
		// 计算url
		var xhr = new XMLHttpRequest();

		bindEvent( xhr, "load", function () {
			var data = xhr.responseText;
			try {
				if ( arg.isJson ) {
					data = JSON.parse( data );
				}
			}
			catch ( e ) {
				arg.onError && arg.onError( xhr );
				return;
			}

			arg.onLoad && arg.onLoad( data, xhr );
		} );

		bindEvent( xhr, "error", function () {
			arg.onError && arg.onError( xhr );
		} );

		xhr.open( arg.method || "get", URL.concatArg( arg.url, arg.arg ), true );

		// 添加headers
		arg.headers && loopObj( arg.headers, function ( key, value ) {
			xhr.setRequestHeader( key, value );
		} );

		xhr.send( arg.data || null );

		return xhr;
	}

	// endregion

	// region 加载
	var onLoad = function () {
		var loadEvent = null;
		return function ( callback ) {
			if ( document.readyState === "complete" ) {
				callback();
			}
			else {
				if ( loadEvent === null ) {
					loadEvent = Event();
					var loadHandle = bindEvent( window, "load", function () {
						loadEvent.trig();
						loadHandle.remove();
						loadEvent = null;
					} );
				}

				loadEvent.regist( callback );
			}
		};
	}();
	// endregion

	// region 导出
	// 路径
	exports.toAbsURL = toAbsURL;

	// 事件
	exports.bindEvent = bindEvent;
	exports.Bind = Bind;
	exports.onInsert = onInsert;

	// 动画
	exports.requestAnimate = requestAnimate;

	// ajax
	exports.ajax = ajax;

	// 加载
	exports.onLoad = onLoad;
	// endregion
} );
/**
 * Created by 白 on 2014/8/4.
 * 封装经典的指针(鼠标/触摸)交互,诸如拖动等
 */

zachModule( function () {
	// region 引入
	var util = imports( "zachUtil.js" ),
		insert = util.insert,
		loopArray = util.loopArray,
		is = util.is,

		LinkedList = imports( "zachLinkedList" ),

		math = imports( "zachMath.js" ),

		Browser = imports( "zachBrowser.js" ),
		bindEvent = Browser.bindEvent,

		moveEvent = AreaEvent(),
		downEvent = AreaEvent(),
		upEvent = AreaEvent(),

		SwipeRadius = 8, // 扫半径
		HMoveRatio = 0.8; // 横向移动比例
	// endregion

	// region util
	// 根据不同的浏览器,给出事件名
	function eventName( touchName, msName, mouseName ) {
		return ua.canTouch ? touchName : ua.msPointer ? msName : mouseName;
	}

	// endregion

	// region 基本事件
	// 区域事件
	function AreaEvent() {
		var events = LinkedList();

		return {
			trig : function () {
				// 根据hoverIndex排序,保证hoverIndex小的后触发,即父区域的事件后于子区域触发
				var arr = LinkedList.toArray( events );
				arr.sort( function ( a, b ) {
					a = a.area;
					b = b.area;
					return a.hoverIndex < b.hoverIndex ? 1 : a.hoverIndex === b.hoverIndex ? 0 : -1;
				} );

				for ( var i = 0, len = arr.length; i !== len; ++i ) {
					arr[i].task.apply( null, arguments );
				}
			},
			regist : function ( area, task ) {
				var node = LinkedList.push( events, {
					area : area,
					task : task
				} );

				return {
					remove : function () {
						events.remove( node );
					}
				};
			}
		};
	}

	function CursorEvent( touchName, msName, mouseName, rootEvent, doEvent ) {
		return function ( area, task, bubble ) {
			if ( area.nodeName ) {
				return bindEvent( area, eventName( touchName, msName, mouseName ), function ( event ) {
					doEvent && doEvent( event );
					task( event, event.zPageX, event.zPageY );
				}, bubble )
			}
			else {
				var cursorHandle, enterEvent;

				util.request( function ( bindEvent ) {
					if ( area.isHover ) {
						bindEvent();
					}
					enterEvent = area.onEnter( bindEvent );
				}, function () {
					cursorHandle = rootEvent.regist( area, task );
					var leaveHandle = area.onLeave( function () {
						leaveHandle.remove();
						cursorHandle.remove();
					} );
				} );

				return {
					remove : function () {
						cursorHandle && cursorHandle.remove();
						enterEvent.remove();
					}
				};
			}
		};
	}

	var onPointerMove = CursorEvent( "touchmove", "MSPointerMove", "mousemove", moveEvent ),
		onPointerDown = CursorEvent( "touchstart", "MSPointerDown", "mousedown", downEvent ),
		onPointerUp = CursorEvent( "touchend", "MSPointerUp", "mouseup", upEvent );

	onPointerMove( document, moveEvent.trig );
	onPointerDown( document, downEvent.trig );
	onPointerUp( document, upEvent.trig );
	// endregion

	// region 域事件
	// 一般的senser,判断是否超出圆
	function outCircle( distanceX, distanceY ) {
		return math.distance( distanceX, distanceY ) > SwipeRadius;
	}

	// 在判断是否出圆的基础上添加方向判断
	function swipeOut( distanceX, distanceY, isHorizontal ) {
		return outCircle( distanceX, distanceY ) ? ( Math.abs( math.sin2( distanceY, distanceX ) ) >= HMoveRatio ) ^ isHorizontal : undefined;
	}

	// 轻触,在没有移除阈值时,同区域抬起时触发
	function onTap( area, response, sense ) {
		sense = sense || outCircle;
		return onPointerDown( area, function ( event, startX, startY ) {
			var senseFailureHandle = onPointerUp( area, function ( event ) {
					// 在区域上抬起时回调
					response( event );
					senseFailureHandle.remove();
				} ),

				senseHandle = onDownMove( function ( event, curX, curY ) {
					// 超出sense的话,tap失败
					if ( sense( curX - startX, curY - startY ) ) {
						senseHandle.remove();
						senseFailureHandle.remove();
					}
				} );
		} );
	}

	// 扫事件,swipeOut是个3态判断,true表示swipe成功,false表示swipe失败,undefined表示还在sense中
	// 若未提供swipeOut,默认是onTap的对立
	function onSwipe( area, response, swipeOut ) {
		swipeOut = swipeOut || function ( distanceX, distanceY ) {
			return outCircle( distanceX, distanceY ) || undefined;
		};

		return onPointerDown( area, function ( event, startX, startY ) {
			var senseHandle = onDownMove( function ( event, curX, curY ) {
				switch ( swipeOut( event, curX - startX, curY - startY ) ) {
					case false:
						senseHandle.remove();
						break;
					case true:
						response( event, curX, curY, startX, startY );
						senseHandle.remove();
						break;
				}
			} );
		} );
	}

	// endregion

	// region down后事件
	// down后事件
	function onDownMove( arg ) {
		var onMove, onUp;
		if ( is.Function( arg ) ) {
			onMove = arg;
		}
		else {
			onMove = arg.onMove;
			onUp = arg.onUp;
		}

		function remove() {
			moveHandle.remove();
			upHandle.remove();
		}

		var moveHandle = onPointerMove( document, function ( event, pageX, pageY ) {
			onMove && onMove( event, pageX, pageY );
		} );

		var upHandle = onPointerUp( document, function ( event ) {
			onUp && onUp( event );
			remove();
		} );

		return {
			remove : remove
		};
	}

	// 拖动,阈值判断成功触发
	function onDrag( arg ) {
		function Track( initialDistance, lastPos ) {
			var lastDirection = initialDistance === 0 ? undefined : initialDistance > 0,
				track = [],
				trackTime = 0,
				lastTime = +new Date(),
				startPos = lastPos;

			return {
				// 去抖动
				test : function ( curPos ) {
					return lastDirection === undefined || !( ( curPos - lastPos ) * ( lastDirection ? 1 : -1 ) < -20 );
				},
				track : function ( curPos ) {
					curPos = curPos || lastPos;

					// 计算目标位置和当前方向
					var curTime = +new Date(),
						duration = curTime - lastTime,
						curDirection = curPos === lastPos ? lastDirection : curPos > lastPos;

					if ( curDirection !== lastDirection || duration > 200 ) {
						// 如果转向或者两次移动时间间隔超过200毫秒,重新计时
						track = [];
						trackTime = 0;
					}
					else {
						// 如果一次移动大于200,清空记录
						if ( duration > 200 ) {
							track = [];
							trackTime = 0;
						}
						else {
							trackTime += duration;

							// 如果记录时间超过300毫秒,移除头部部分记录,使其减少到300毫秒
							while ( trackTime > 300 ) {
								trackTime -= track.shift().duration;
							}

							track.push( {
								duration : duration,
								distance : curPos - lastPos
							} );
						}
					}

					// 更新数据
					lastDirection = curDirection;
					lastPos = curPos;
					lastTime = curTime;
				},
				distance : function () {
					return lastPos - startPos + initialDistance;
				},
				direction : function () {
					return lastDirection;
				},
				speed : function () {
					var totalDiff = 0;
					loopArray( track, function ( unit ) {
						totalDiff += unit.distance;
					} );
					return trackTime === 0 ? 0 : totalDiff / trackTime;
				}
			};
		}

		var startTime = new Date(),
			trackX = Track( arg.distanceX || 0, arg.curX ),
			trackY = Track( arg.distanceY || 0, arg.curY );

		function dragInfo() {
			return {
				distanceX : trackX.distance(),
				distanceY : trackY.distance(),
				directionX : trackX.direction(),
				directionY : trackY.direction()
			}
		}

		return onDownMove( {
			onMove : function ( event, pageX, pageY ) {
				if ( trackX.test( pageX ) && trackY.test( pageY ) ) {
					trackX.track( pageX );
					trackY.track( pageY );

					arg.onMove && arg.onMove( dragInfo() );
				}
			},
			onUp : function () {
				trackX.track();
				trackY.track();

				// 触发拖动结束事件
				arg.onUp && arg.onUp( insert( dragInfo(), {
					speedX : trackX.speed(),
					speedY : trackY.speed(),
					duration : +new Date() - startTime
				} ) );
			}
		} );
	}

	// endregion

	// region 导出
	function SwipeHV( isHorizontal ) {
		return function ( area, response ) {
			return onSwipe( area, response, function ( pageX, pageY ) {
				return swipeOut( pageX, pageY, isHorizontal );
			} );
		};
	}

	exports.onPointerMove = onPointerMove;
	exports.onPointerDown = onPointerDown;
	exports.onPointerUp = onPointerUp;

	exports.onTap = onTap;
	exports.onSwipe = onSwipe;
	exports.onSwipeH = SwipeHV( true );
	exports.onSwipeV = SwipeHV( false );

	exports.onDownMove = onDownMove;
	exports.onDrag = onDrag;
	// endregion
} );
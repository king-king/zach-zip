/**
 * Created by 白 on 2014/11/10.
 * 封装一些经典的文件系统需求
 */

require( "./zachNode.js" );
var Path = require( "path" ),
	util = require( "./zachUtil.js" ),
	crypto = require( "crypto" ),
	fs = require( "fs" );

// region util
// 创建目录
function mkdir( path, callback ) {
	fs.exists( path, function ( exists ) {
		if ( !exists ) {
			var dir = "";

			util.loopArrayAsync( splitPath( path ), function ( done, dirParts, i ) {
				dir += ( i === 0 ? "" : "/" );
				dir += dirParts;
				fs.mkdir( dir, done )
			}, callback );
		}
		else {
			callback();
		}
	} );
}

// 将contentList转换为contentMap
function listToMap( list ) {
	var retVal = {}, cwd = process.cwd();
	util.loopArray( list, function ( content ) {
		retVal[Path.relative( cwd, content.path )] = content;
	} );
	return retVal;
}
// endregion

// region 路径
// 拆分路径
function splitPath( path ) {
	return Path.normalize( path ).replace( /\\/g, "/" ).split( "/" );
}

// 将带通配符的路径解析为对应的文件并回调,尚不支持文件夹的通配符
function resolvePath( path, callback ) {
	if ( /\?|\*/gi.test( path ) ) {
		var dir = Path.dirname( path ),
			wildReg = new RegExp( Path.basename( path ).replace( ".", "\\." ).replace( "?", "." ).replace( "*", ".*" ) ),
			matchedFiles = [];

		// 遍历目录,符合通配符的加入到inFile中
		fs.readdir( dir, function ( err, fileList ) {
			if ( err ) {
				callback( err, null );
			}
			else {
				util.loopArray( fileList, function ( fileName ) {
					wildReg.test( fileName ) && matchedFiles.push( {
						path : Path.join( dir, fileName )
					} );
				} );

				callback( err, matchedFiles );
			}
		} );
	}
	else {
		callback( null, [{
			path : path
		}] );
	}
}

// 列出路径下的所有文件
function listDir( dir, callback, doDir ) {
	var result = [];

	util.recursion( function readDir( dir, callback ) {
		fs.readdir( dir, function ( err, fileList ) {
			if ( err !== null ) {
				callback( err );
			}
			else {
				util.loopArrayAsync( fileList, function ( done, path ) {
					path = Path.join( dir, path );

					fs.stat( path, function ( err, stat ) {
						if ( stat.isDirectory() ) {
							readDir( path, done );

							if ( doDir ) {
								result.push( {
									path : path,
									isDirectory : true
								} );
							}
						}
						else {
							result.push( {
								path : path
							} );
							done();
						}
					} );
				}, callback, true );
			}
		} );
	}, dir, function () {
		callback( null, result );
	} );
}

// 判断路径是否属于目录
function inDir( srcPath, tarPath ) {
	return !/^\.\./.test( Path.relative( tarPath, srcPath ) );
}
// endregion

// region content
// 读取文件,制作成content格式
function readContent( arg, callback ) {
	var path = arg.path,
		loader = util.Loader(),
		retVal = {
			path : path
		};

	arg = util.extend( {
		data : true
	}, arg );

	function error( err ) {
		callback && callback( err );
		callback = null;
	}

	util.procedure( [
		function ( callback ) {
			// 获取时间戳
			if ( arg.timestamp ) {
				loader.load( function ( done ) {
					fs.stat( path, function ( err, stat ) {
						if ( err !== null ) {
							error( err );
						}
						else {
							retVal.timestamp = stat.mtime.getTime();
						}
						done();
					} );
				} );
			}

			// 获取内容
			if ( arg.data ) {
				loader.load( function ( done ) {
					fs.readFile( path, {
						encoding : arg.encoding
					}, function ( err, content ) {
						if ( err !== null ) {
							error( err );
						}
						else {
							retVal.data = content;
						}
						done();
					} );
				} );
			}

			loader.start( callback );
		},
		function () {
			var loader = util.Loader();

			// 获取md5
			if ( arg.md5 ) {
				var md5 = crypto.createHash( 'md5' );

				// 如果已经读取了文件内容,直接算
				if ( retVal.data ) {
					md5.update( retVal.data, arg.encoding );
					retVal.md5 = md5.digest( 'hex' );
				}
				// 否则读一遍
				else {
					loader.load( function ( done ) {
						var s = fs.ReadStream( path );
						s.on( "data", function ( d ) {
							md5.update( d );
						} );

						s.on( "end", function () {
							done();
							retVal.md5 = md5.digest( 'hex' );
						} );
					} );
				}
			}

			loader.start( function () {
				callback && callback( null, retVal );
			} );
		}
	] );
}

// 写入content,创建响应的文件夹
function writeContent( arg, callback ) {
	var dir = Path.dirname( arg.path );

	util.request( function ( write ) {
		if ( !dir || dir === "." ) {
			write();
		}
		else {
			mkdir( dir, write );
		}
	}, function () {
		fs.writeFile( arg.path, arg.data, {
			encoding : arg.encoding
		}, callback );
	} );
}

// 读取一组数据
function readContentList( inContentList, callback ) {
	var contentList = [];

	util.loopArrayAsync( inContentList, function ( done, content, i ) {
		util.request( function ( pushResult ) {
			if ( content.isDirectory ) {
				pushResult( content );
				done();
			}
			else {
				readContent( content, function ( err, result ) {
					if ( err ) {
						callback && callback( err );
					}
					else {
						pushResult( result )
					}
					done();
				} );
			}
		}, function ( result ) {
			contentList[i] = result;
		} );
	}, function () {
		callback && callback( null, contentList );
	} );
}
// endregion

// region 比较
// 比较内容列表,根据md5或者timestamp计算出未改变,更新,创建和删除
function compareContentList( srcList, tarList, by ) {
	var srcMap = listToMap( srcList ), tarMap = listToMap( tarList ),
		retVal = [];

	function result( tarContent, type ) {
		return retVal.push( util.extend( tarContent, {
			type : type
		} ) );
	}

	util.loopObj( tarMap, function ( path, tar ) {
		var src = srcMap[path];
		result( tar, src ? tar[by] === src[by] && tar.isDirectory === src.isDirectory ? "not-modified" : "update" : "create" );
	} );

	util.loopObj( srcMap, function ( path, content ) {
		if ( !( path in tarMap ) ) {
			result( content, "remove" );
		}
	} );

	return retVal;
}

// 判断两个列表是否相等
function isContentListIdentify( arg1, arg2, arg3 ) {
	return util.loopArray( arg2 === undefined ? arg1 : compareContentList( arg1, arg2, arg3 ), function ( content ) {
			return content.type !== "not-modified" ? true : undefined;
		} ) || false;
}

// 写入一个比较列表
function writeCompareContentList( compareList, callback ) {
	util.procedure( [
		// 删除remove
		function ( callback ) {
			util.loopArrayAsync( compareList, function ( done, content ) {
				content.type === "remove" && content.isDirectory ? fs.rmdir( content.path, done ) : fs.unlink( content.path, done );
			}, callback );
		},

		// 更新update和create
		function () {
			util.loopArrayAsync( compareList, function ( done, content ) {
				var type = content.type;
				( type === "create" || type === "update" ) &&
				content.isDirectory ? mkdir( content.path, done ) : writeContent( content, done );
			}, callback );
		}
	] );
}
// endregion

// region json读写
// 读取json文件
function readJSONFile( path, callback, ignoreEmpty ) {
	readContent( {
		path : path,
		encoding : "utf8"
	}, function ( err, content ) {
		if ( err ) {
			if ( ignoreEmpty ) {
				callback( null, null );
			}
			else {
				callback( err );
			}
		}

		if ( content ) {
			try {
				var result = JSON.parse( content.data );
			}
			catch ( e ) {
				callback( e );
				return;
			}

			callback( null, result );
		}
	} );
}

// 写入json文件
function writeJSONFile( path, data, callback, indent ) {
	writeContent( {
		path : path,
		encoding : "utf8",
		data : JSON.stringify( data, null, indent || 4 ) + "\n"
	}, callback );
}
// endregion

exports.mkdir = mkdir;
exports.listToMap = listToMap;

exports.splitPath = splitPath;
exports.inDir = inDir;

exports.resolvePath = resolvePath;
exports.listDir = listDir;

exports.readContent = readContent;
exports.writeContent = writeContent;
exports.readContentList = readContentList;

exports.compareContentList = compareContentList;
exports.writeCompareContentList = writeCompareContentList;
exports.isContentListIdentify = isContentListIdentify;

exports.readJSONFile = readJSONFile;
exports.writeJSONFile = writeJSONFile;
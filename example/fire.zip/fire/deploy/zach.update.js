/**
 * Created by 白 on 2015/1/9.
 */

var momoko = require( "momoko" );

momoko.update( {
	dir : "../zach",
	host : "http://123.57.6.235:16789",
	name : "zach",
	track : "zach.momoko"
}, momoko.log );
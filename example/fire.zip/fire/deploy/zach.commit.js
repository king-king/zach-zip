/**
 * Created by Zuobai on 2015/1/3.
 */

var momoko = require( "momoko" );

momoko.commit( {
	dir : "../zach",
	host : "http://123.57.6.235:16789",
	name : "zach",
	track : "zach.momoko"
}, momoko.log );
/**
 * Created by Json on 2015/2/13.
 */

zachModule( function () {
	var dom = imports( "zachDOM" );
	var colors = ["#00ff00", "yellow", "blue", "green", "orange", "aqua", "fuchsia", "purple", "lime", "teal"];
	var munitions = []; // 弹药，已经爆炸的弹药dead字段为true，不必绘制
	var fragments = []; // 一个二维数组，存放爆炸的碎片,碎片光芒熄灭后dead字段为true，不必绘制

	var util = imports( "zachUtil" ),
		loop = util.loop,
		loopArray = util.loopArray;


	function getRandom( start, end ) {
		return Math.random() * (end - start) + start;
	}


	var audioFireFlys = [];
	var audioBooms = [];

	var fireFlys = ["audio/firefly.mp3", "audio/firefly2.mp3"];

	loop( 3, function () {
		var audio = document.createElement( "audio" );
		audio.src = "data:audio/mpeg;base64," + fireData.boom;
		audioBooms.push( audio );
	} );

	loopArray( fireData.fly, function ( src ) {
		var audio = document.createElement( "audio" );
		audio.src = "data:audio/mpeg;base64," + src;
		audioFireFlys.push( audio );
	} );


	var offScreenPoint = {};

	function getOffScreenPoint() {
		loopArray( colors, function ( color ) {
			var canvas = document.createElement( "canvas" );
			canvas.width = canvas.height = 3;
			var ctx = canvas.getContext( "2d" );
			ctx.fillStyle = color;
			ctx.fillRect( 0, 0, canvas.width, canvas.height );
			offScreenPoint[color] = canvas;
		} );
	}

	getOffScreenPoint();
	function drawPoint( ctx, p ) {
		ctx.drawImage( offScreenPoint[p.color], p.x, p.y );
	}

	var vs = [];
	var number = 30;
	var d = 2 * Math.PI / number;
	loop( number, function ( i ) {
		vs.push( {
			vy : getRandom( 5, 7 ) * Math.sin( d * i ),
			vx : getRandom( 5, 7 ) * Math.cos( d * i )
		} )
	} );
	// 在指定的位置爆炸，产生碎片,开启音效
	function boomFire( x, y ) {
		playMusic( audioBooms[getRandom( 0, audioBooms.length - 1 ) << 0] );
		var tinyFragments = [];
		var color = colors[getRandom( 0, colors.length - 1 ) << 0];
		loop( number, function ( i ) {
			tinyFragments.push( {
				dead : false,
				x : x,
				y : y,
				color : color,
				vx : vs[i].vx,
				vy : vs[i].vy
			} );
		} );
		fragments.push( {
			dead : false,
			f : tinyFragments
		} );
	}

	// 播放音乐
	function playMusic( audio ) {
		audio.load();
		audio.play();
	}

	function fire( canvas ) {
		var w = canvas.width = canvas.offsetWidth;
		var h = canvas.height = canvas.offsetHeight;
		var ctx = canvas.getContext( "2d" );

		function shotFire() {
			playMusic( audioFireFlys[getRandom( 0, audioFireFlys.length - 1 ) << 0] );
			munitions.push( {
				dead : false,
				x : getRandom( w / 4, w * 3 / 4 ),
				y : h,
				color : colors[getRandom( 0, colors.length - 1 ) << 0],
				vx : getRandom( -1, 1 ),
				vy : -getRandom( 6, 7 )
			} );
		}

		var deadCount = 0;
		var handle = dom.requestAnimate( function () {
			//ctx.fillStyle = "rgba(0,0,0,0.15)";
			ctx.clearRect( 0, 0, w, h );
			// 将所有的未爆弹绘制出来
			loop( munitions.length, function ( i ) {
				if ( !munitions[i].dead ) {
					// 如果还没有爆炸，则将这个弹药绘制出来
					munitions[i].vy += 0.065;
					munitions[i].y += munitions[i].vy;
					if ( Math.abs( munitions[i].vy ) < 0.2 ) {
						// 速度太慢就认为是该爆炸了
						munitions[i].dead = true;
						boomFire( munitions[i].x, munitions[i].y );
					}
					else {
						drawPoint( ctx, munitions[i] );
					}
				}
			} );
			// 绘制烟花
			loopArray( fragments, function ( fragmentItem ) {
				if ( !fragmentItem.dead ) {
					// 只绘制没有熄灭的
					loopArray( fragmentItem.f, function ( fragment ) {
						if ( !fragment.dead ) {
							fragment.vx *= 0.96;
							fragment.vy *= 0.96;
							fragment.x += fragment.vx;
							fragment.y += fragment.vy;
							if ( Math.abs( fragment.vx ) < 0.2 ) {
								// 速度太慢就算是死亡
								fragment.dead = true;
								deadCount += 1;
								if ( deadCount / fragmentItem.f.length > 0.6 ) {
									//  如果超过90%已经熄灭，则判定整体死亡
									fragmentItem.dead = true;
									deadCount = 0;
									// 简易版的烟花是一个接一个放烟花
									fragments.pop();
									munitions.pop();
									setTimeout( function () {
										shotFire();
									}, 1000 );
								}
							}
							else {
								drawPoint( ctx, fragment );
							}
						}
					} );
				}
			} );
		} );

		handle.remove();

		return {
			// 重新开始燃放烟花，而不是继续，界面清空
			reStart : function () {
				handle.remove();
				ctx.clearRect( 0, 0, w, h );
				munitions = [];
				fragments = [];
				shotFire();
				handle.start();
			},
			// 继续开始燃放，从上次stop的时候继续燃放
			start : function () {
				handle.remove();
				shotFire();
				handle.start();
			},
			// 暂停燃放
			pause : function () {
				handle.remove();
			}

		}

	}

	module.exports = fire;
} );
/**
 * Created by Json on 2015/2/14.
 */
var a = {
	"code" : 200,
	"data" : {
		"thumbnail" : "http://firstpage.blob.core.chinacloudapi.cn/resource/07bc24580c51281be5ed52e0ac270beb.jpg",
		"title" : "Engel Shanghai Annual Dinner ",
		"description" : "Engel Shanghai Annual Dinner 2015",
		"mode" : "push",
		"pageSwitch" : {"animateId" : "push"},
		"backgroud" : {"color" : "#FFFFFF"},
		"music" : {"src" : "http://firstpage.blob.core.chinacloudapi.cn/resource/410fe45c5db2f0a19534d5a0827ba769.mp3"},
		"pages" : [{
			"layout" : {
				"label" : "ImageText01",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/e2291c68b7e331af15350ddbd6120b8e.jpg"],
				"text" : ["恩格尔上海2015年年会 ", "Engel Shanghai Annual Dinner 2015"],
				"imageinfo" : []
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/359c6134f201283d45b0c2a5a3362988.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/2f62e72302663772fef40158bb6da5c8.jpg", "rgba(255,255,255,0.8)", "http://firstpage.blob.core.chinacloudapi.cn/resource/92657efd1e44999bd34abb5877471250.png", "https://firstpage.blob.core.chinacloudapi.cn/resource/0e3a6096212efdffd9be6c2dbea24b1e.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 15,
					"y" : 285,
					"width" : 290,
					"height" : 178,
					"maskRadius" : 0
				}, {"x" : 15, "y" : 333, "width" : 292, "height" : 55, "rotate" : -0.0113226, "animation" : "fly-into-left", "maskRadius" : 0}, {
					"x" : -6,
					"y" : 607,
					"width" : 186,
					"height" : 6,
					"rotate" : 4.588034,
					"animation" : "emerge-bottom",
					"maskRadius" : 0
				}]
			}
		}, {
			"layout" : {
				"label" : "MutipleImage02",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/a3b688093c59c09abfdb4dbe31761146.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/344bcd6dc21b0dbdc5fa3384428f6fd4.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/53168972965ce4eeed59eb827ba46178.jpg"],
				"imageinfo" : []
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(27,27,27,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/f34e9d6246302482277c29a2944d329f.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/77af89a8085d76f475fe82c682e408a5.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/f0625adfb37f18c4b0d596c031d5b259.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/f4855f3cea7ab511aaf8c99cd39fb9e8.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/63ef6720586923c7fafe3be9f072e3ab.jpg"],
				"imageinfo" : [null, {
					"x" : 2,
					"y" : 44,
					"width" : 324,
					"height" : 83,
					"rotate" : -0.02325162,
					"animation" : "fly-into-left",
					"maskRadius" : 0
				}, {
					"x" : 10,
					"y" : 143,
					"width" : 292,
					"height" : 132,
					"rotate" : -0.01481373,
					"animation" : "fly-into-left",
					"maskRadius" : 0
				}, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 0,
					"y" : 0,
					"width" : 0,
					"height" : 0,
					"rotate" : 0.0,
					"maskRadius" : 0
				}, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(233,233,233,1)", "rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/ab38094873d963e7db2a5dadcd783a1a.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/b655abb8ad4116627a6d308e347a0b85.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/0c89dd4f60ca12fb53f358a2db546761.png"],
				"imageinfo" : [null, {"x" : 20, "y" : 60, "width" : 280, "height" : 257, "maskRadius" : 0}, {
					"x" : 0,
					"y" : 0,
					"width" : 0,
					"height" : 0,
					"rotate" : 0.0,
					"maskRadius" : 0
				}, {"x" : 32, "y" : 347, "width" : 251, "height" : 46, "rotate" : 0.0, "animation" : "fly-into-top", "maskRadius" : 0}, {
					"x" : 12,
					"y" : 410,
					"width" : 293,
					"height" : 54,
					"rotate" : 0.0,
					"animation" : "fly-into-bottom",
					"maskRadius" : 0
				}]
			}
		}, {
			"layout" : {
				"label" : "ImageText04",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/a4f5837959534c8e5b04fd7ce56e2c03.jpg"],
				"imageinfo" : []
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/2202490fecfd0da50e6d109609bc2652.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/a5394dff20b13373d24667e4a9f2c425.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/6399268a3fa318244a0628a3476e618e.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 21,
					"y" : 375,
					"width" : 261,
					"height" : 54,
					"rotate" : 0.0,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {"x" : 14, "y" : 432, "width" : 276, "height" : 9, "rotate" : 0.0, "animation" : "fly-into-left", "maskRadius" : 0}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/5906895f52319afa677b67cf8a1d2cad.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/fe549f080c5470e1139d9cb8417aabd8.jpg", "rgba(255,255,255,0.8)", "http://firstpage.blob.core.chinacloudapi.cn/resource/1fa0b2397ca3fda6a77bb25ce81388f2.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/7ef21912d95eca9e44be82fcc25c9146.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 15,
					"y" : 285,
					"width" : 290,
					"height" : 178,
					"maskRadius" : 0
				}, {"x" : 40, "y" : 313, "width" : 248, "height" : 12, "rotate" : 0.0, "animation" : "emerge-top", "maskRadius" : 0}, {
					"x" : 15,
					"y" : 382,
					"width" : 285,
					"height" : 75,
					"rotate" : 1.730218E-17,
					"animation" : "fade-in",
					"maskRadius" : 0
				}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(27,27,27,1)", "https://firstpage.blob.core.chinacloudapi.cn/resource/0e3a6096212efdffd9be6c2dbea24b1e.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/1d5ee3c90e6fc3559584014aa02a68a0.png", "rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/b7f86fbc753a35a066c07b663ab890c3.jpg"],
				"imageinfo" : [null, {
					"x" : 258,
					"y" : 32,
					"width" : 44,
					"height" : 24,
					"rotate" : 0.0,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {
					"x" : -4,
					"y" : 45,
					"width" : 326,
					"height" : 44,
					"rotate" : 2.834612E-17,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {
					"x" : 14,
					"y" : 260,
					"width" : 283,
					"height" : 240,
					"rotate" : 0.06981317,
					"animation" : "fall-down-and-shake",
					"maskRadius" : 0
				}, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/20e926284f1aded6ef3147c64cf5e5e3.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/29bc6682fb7863f4258984b8ec334b05.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/df49193d726a829f12edc523a9d6f210.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 30,
					"y" : 357,
					"width" : 255,
					"height" : 56,
					"rotate" : 0.0,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {"x" : 42, "y" : 425, "width" : 226, "height" : 71, "rotate" : 0.0, "animation" : "fly-into-left", "maskRadius" : 0}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/8a1339d38502eeb517719728b6f9b91a.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/d86bad19262f6bba1832771e7b68103d.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/fbe9cc3be3e11a55cfd8cbb42bad0d3a.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 19,
					"y" : 355,
					"width" : 279,
					"height" : 58,
					"rotate" : 0.0,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {"x" : 2, "y" : 415, "width" : 319, "height" : 62, "rotate" : 0.0, "animation" : "fly-into-left", "maskRadius" : 0}]
			}
		}, {
			"layout" : {
				"label" : "ImageText07",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/8c38a40fa3c35733d45395ef5b3e29a0.jpg"],
				"imageinfo" : []
			}
		}, {
			"layout" : {
				"label" : "MutipleImage02",
				"image" : ["http://firstpage.blob.core.chinacloudapi.cn/resource/884476a7ac414f56af8015ac4fa3b666.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/6555a171cebdd432a7970d0491b09354.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/02bff0fe359b3a3fceeb16fd52259494.jpg"],
				"imageinfo" : []
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(233,233,233,1)", "rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/57c1776040a957283fdfdc5045e6ab43.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/3dc16e3260d500f419d9da2cd392c897.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/b2f83e616eda35484cb178be530f1129.png"],
				"imageinfo" : [null, {"x" : 20, "y" : 60, "width" : 280, "height" : 257, "maskRadius" : 0}, {
					"x" : 0,
					"y" : 0,
					"width" : 0,
					"height" : 0,
					"rotate" : 0.0,
					"maskRadius" : 0
				}, {"x" : 83, "y" : 357, "width" : 153, "height" : 27, "rotate" : 0.0, "animation" : "fly-into-top", "maskRadius" : 0}, {
					"x" : 16,
					"y" : 401,
					"width" : 286,
					"height" : 18,
					"rotate" : 0.0,
					"animation" : "fly-into-bottom",
					"maskRadius" : 0
				}]
			}
		}, {
			"layout" : {
				"label" : "custom",
				"image" : ["rgba(255,255,255,1)", "http://firstpage.blob.core.chinacloudapi.cn/resource/51f9e3207df0af56a1f635d7158828b7.jpg", "http://firstpage.blob.core.chinacloudapi.cn/resource/2a8c8b8b0b6d729d45088c1592c23020.png", "http://firstpage.blob.core.chinacloudapi.cn/resource/917d1da51122ee0fda475033adab0a44.png"],
				"imageinfo" : [null, {"x" : 0, "y" : 0, "width" : 0, "height" : 0, "rotate" : 0.0, "maskRadius" : 0}, {
					"x" : 34,
					"y" : 365,
					"width" : 247,
					"height" : 17,
					"rotate" : 0.0,
					"animation" : "fly-into-right",
					"maskRadius" : 0
				}, {"x" : 8, "y" : 412, "width" : 299, "height" : 53, "rotate" : 0.0, "animation" : "fly-into-left", "maskRadius" : 0}]
			}
		}],
		"author" : "ENGELSH0519",
		"headimgurl" : "http://firstpage.blob.core.chinacloudapi.cn/resource/117386c9ee56dd65e89284cce4d3a1b5.jpg",
		"userworks" : {
			"title" : "热门初页",
			"works" : [{
				"thumbnail" : "https://firstpage.blob.core.chinacloudapi.cn/resource/d53bb8d71cf2c8d981ba6d7d2b3d5fdf.jpg",
				"title" : "《丙中洛的眼泪》",
				"url" : "/18327"
			}, {
				"thumbnail" : "http://chuye.cloud7.com.cn/Cloud7BeginPage/Content/Image/logo.png",
				"title" : "最美体验师",
				"url" : "/27657"
			}, {
				"thumbnail" : "http://firstpage.blob.core.chinacloudapi.cn/resource/54e8f3a6fe82294740cf49c7c5246535.jpg",
				"title" : "爱上日本 只需那么一秒",
				"url" : "/222008"
			}]
		},
		"copyright" : 1,
		"praise" : 0
	}
}
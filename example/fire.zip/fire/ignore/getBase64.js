/**
 * Created by Json on 2015/2/13.
 */
var fs = require( "fs" );

fs.readFile( "../audio/firefly2.mp3", {
	encoding : "base64"
}, function ( err, content ) {
	// content是结果
	fs.writeFile( "out,", content, function ( e ) {
		console.log( e )
	} )
} );